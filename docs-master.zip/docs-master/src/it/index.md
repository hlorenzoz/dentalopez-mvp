---
features:
  - 
    details: 'Yii offre la massima funzionalità aggiungendo il minor overhead possibile.'
    icon: '<svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="#F18A2A" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M6 2a.5.5 0 0 1 .47.33L10 12.036l1.53-4.208A.5.5 0 0 1 12 7.5h3.5a.5.5 0 0 1 0 1h-3.15l-1.88 5.17a.5.5 0 0 1-.94 0L6 3.964 4.47 8.171A.5.5 0 0 1 4 8.5H.5a.5.5 0 0 1 0-1h3.15l1.88-5.17A.5.5 0 0 1 6 2"/></svg>'
    title: Veloce
  - 
    details: 'Le impostazioni predefinite e gli strumenti integrati ti aiutano a scrivere codice solido e sicuro.'
    icon: '<svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="#83C933" viewBox="0 0 16 16"><path d="M5.338 1.59a61 61 0 0 0-2.837.856.48.48 0 0 0-.328.39c-.554 4.157.726 7.19 2.253 9.188a10.7 10.7 0 0 0 2.287 2.233c.346.244.652.42.893.533q.18.085.293.118a1 1 0 0 0 .101.025 1 1 0 0 0 .1-.025q.114-.034.294-.118c.24-.113.547-.29.893-.533a10.7 10.7 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067c-.53 0-1.552.223-2.662.524zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.8 11.8 0 0 1-2.517 2.453 7 7 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7 7 0 0 1-1.048-.625 11.8 11.8 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 63 63 0 0 1 5.072.56"/><path d="M10.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0"/></svg>'
    title: Sicuro
  - 
    details: 'Scrivi più codice in meno tempo con API semplici ma potenti e la generazione di codice.'
    icon: '<svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="#40B3D8" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M0 0h1v15h15v1H0zm10 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-1 0V4.9l-3.613 4.417a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61L13.445 4H10.5a.5.5 0 0 1-.5-.5"/></svg>'
    title: Efficiente
hero:
  actions:
    - 
      link: guide/intro/what-is-yii.html
      text: 'Per iniziare'
      theme: brand
  class: homeHero2
  image:
    alt: Yii
    src: /images/yii_logo.svg
  name: 'Yii3 Framework'
  tagline: 'Un framework semplice, potente e veloce. Scopri la guida moderna e definitiva a Yii che hai sempre desiderato.'
  text: Documentazione
layout: home
---

<br><br>

- [La guida definitiva](guide/) — la guida completa che copre tutti gli
  aspetti del framework.
- [Ricettario della comunità](cookbook/) — una raccolta di suggerimenti,
  trucchi e soluzioni forniti dalla comunità per le attività di sviluppo Yii
  più comuni.
- [Internals](internals/) — documentazione per gli sviluppatori che
  contribuiscono al framework Yii stesso, comprese linee guida, flussi di
  lavoro e best practice.
