# Console applications

Console applications are mainly used to create utility, background
processing and maintenance tasks.

## Getting started

If you're using [yiisoft/app](https://github.com/yiisoft/app) or
[yiisoft/app-api](https://github.com/yiisoft/app-api), console support is
already included.  You can access the entry point as:

```
./yii
```

If you want a standalone console-only application, use the
[yiisoft/app-console](https://github.com/yiisoft/app-console) project
template:

```sh
composer create-project yiisoft/app-console your-project
```

To add console support to an existing project from scratch, refer to the
[yiisoft/yii-console package
documentation](https://github.com/yiisoft/yii-console).

Out of the box only `serve` command is available. It's starting PHP built-in
web server to serve the application locally.

Commands are executed with `symfony/console`. To create your own console
command, you need to define a command:

```php
<?php
namespace App\Command\Demo;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Yiisoft\Yii\Console\ExitCode;

#[AsCommand(
    name: 'demo:hello',
    description: 'Echoes hello',
    
)]
class HelloCommand extends Command
{   
    public function configure(): void
    {
        $this            
            ->setHelp('This command serves for demo purpose')
            ->addArgument('name', InputArgument::OPTIONAL, 'Name to greet', 'anonymous');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        $name = $input->getArgument('name');
        $io->success("Hello, $name!");
        return ExitCode::OK;
    }
}
```

Now register the command in `config/params.php`:

```php
return [
    'yiisoft/yii-console' => [
        'commands' => [
            'demo:hello' => App\Demo\HelloCommand::class,
        ],
    ],    
];
```

After it's done, the command could be executed as

```
./yii demo:hello Alice
```


## Referensi

- [Symfony Console component
  guide](https://symfony.com/doc/current/components/console.html)
